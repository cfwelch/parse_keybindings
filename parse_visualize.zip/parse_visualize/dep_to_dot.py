
from stanford_corenlp_pywrapper import CoreNLP
import subprocess, string, sys, os

PATH = sys.argv[1]
pathz = []
with open(PATH + "config") as handle:
    pathz = handle.readlines()

proc = CoreNLP(configdict={'annotators':"tokenize,ssplit,pos,depparse"}, output_types=['depparse'], corenlp_jars=[pathz[0].strip() + "*"])
clipb = subprocess.check_output("xclip -selection c -o", shell=True)
parsed = proc.parse_doc(clipb.strip())
tokens = parsed['sentences'][0]['tokens']
deps = parsed['sentences'][0]['deps_basic']
sent = ' '.join(parsed['sentences'][0]['tokens'])
print(sent)

safechars = bytearray(('_-.() ' + string.digits + string.ascii_letters).encode())
allchars = bytearray(range(0x100))
deletechars = bytearray(set(allchars) - set(safechars))
filename = "DEP " + sent.encode('ascii', 'ignore').translate(None, deletechars).decode()
dotname = "{0}".format(r'"%s"' % (PATH + "parses/" + filename + ".dot"))
pngname = "{0}".format(r'"%s"' % (PATH + "parses/" + filename + ".png"))

edge_list = []

for dep in deps:
    edge_list.append(str(dep[1]) + " -> " + str(dep[2]) + " [label=\"" + dep[0] + "\"]")

with open(PATH + "parses/" + filename + ".dot", "w") as h:
    h.write("digraph {\n")
    h.write("\t-1 [label=\"root\"]\n")
    for i in range(0, len(tokens)):
        h.write("\t" + str(i) + " [label=\"" + tokens[i] + "\"]\n")
    for line in edge_list:
        h.write("\t" + line + "\n")
    h.write("}")

os.system("dot -Tpng " + dotname + " > " + pngname)
subprocess.Popen(["eog", PATH + "parses/" + filename + ".png"])
#os.system("rm {0}.dot".format(r'"%s"' % PATH + filename))

 

