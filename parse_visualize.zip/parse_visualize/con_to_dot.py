
from stanford_corenlp_pywrapper import CoreNLP
import subprocess, string, sys, os

PATH = sys.argv[1]
pathz = []
with open(PATH + "config") as handle:
    pathz = handle.readlines()

proc = CoreNLP(configdict={'annotators':"tokenize,ssplit,pos,parse"}, output_types=['parse'], corenlp_jars=[pathz[0].strip() + "*"])
clipb = subprocess.check_output("xclip -selection c -o", shell=True)
parsed = proc.parse_doc(clipb.strip())
print(parsed)
lines = parsed['sentences'][0]['parse']
sent = ' '.join(parsed['sentences'][0]['tokens'])
print(sent)
print("\n\n")
print(lines)
lines = lines.split("\n")

ZS = 5
gl = ""
for line in lines:
    if not line.startswith("#") and line.strip() != "":
        gl += " " + line.strip()
gl = gl.strip()

safechars = bytearray(('_-.() ' + string.digits + string.ascii_letters).encode())
allchars = bytearray(range(0x100))
deletechars = bytearray(set(allchars) - set(safechars))
filename = "CON " + sent.encode('ascii', 'ignore').translate(None, deletechars).decode()
dotname = "{0}".format(r'"%s"' % (PATH + "parses/" + filename + ".dot"))
pngname = "{0}".format(r'"%s"' % (PATH + "parses/" + filename + ".png"))

edge_list = []
n_stack = []
n_dict = {}
counter = 0
edge = ""
prev = ""
for _c in gl:
    if _c in [")", "("]:
        if prev.strip() != "":
            prev = prev.strip()
            #print(": " + prev)
            if " " in prev:
                parts = prev.split(" ")
                name1 = "N" + str(counter).zfill(ZS)
                counter += 1
                if len(n_stack) > 0:
                    edge_list.append(n_stack[-1] + " -> " + name1)
                n_stack.append(name1)
                n_dict[name1] = parts[0]
                name2 = "N" + str(counter).zfill(ZS)
                counter += 1
                edge_list.append(n_stack[-1] + " -> " + name2)
                n_dict[name2] = parts[1]
            else:
                newname = "N" + str(counter).zfill(ZS)
                if len(n_stack) > 0:
                    edge_list.append(n_stack[-1] + " -> " + newname)
                n_stack.append(newname)
                n_dict[newname] = prev
                counter += 1
            prev = ""
        else:
            n_stack = n_stack[:-1]
    else:
        prev += _c

with open(PATH + "parses/" + filename + ".dot", "w") as h:
    h.write("digraph {\n")
    for k in sorted(n_dict.iterkeys()):
        h.write("\t" + k + " [label=\"" + n_dict[k] + "\"]\n")
    for line in edge_list:
        h.write("\t" + line + "\n")
    h.write("}")

os.system("dot -Tpng " + dotname + " > " + pngname)
subprocess.Popen(["eog", PATH + "parses/" + filename + ".png"])
#os.system("rm {0}.dot".format(r'"%s"' % PATH + filename))

